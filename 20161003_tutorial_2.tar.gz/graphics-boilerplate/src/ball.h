#ifndef BALL_H
#define BALL_H


class Ball {
public:
    Ball() {}
    Ball(float x, float y, color_t color);
    glm::vec3 position;
    float rotation;
    void draw(glm::mat4 VP);
    void set_position(float x, float y);
    bool on_ground();
    void tick();
    double speed;
    double speed_y;
    double acceleration;
    bounding_box_t bounding_box();
    
private:
    VAO *object;
};




#endif // BALL_H
